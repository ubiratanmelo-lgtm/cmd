import DocesSalgadosSystem from './components/DocesSalgadosSystem'

export default function Home() {
  return (
    <main>
      <DocesSalgadosSystem />
    </main>
  )
}